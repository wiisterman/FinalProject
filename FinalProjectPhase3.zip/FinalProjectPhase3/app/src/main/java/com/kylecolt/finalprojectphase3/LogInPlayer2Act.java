package com.kylecolt.finalprojectphase3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;

public class LogInPlayer2Act extends AppCompatActivity {

    private DatabaseManager udb;
    private EditText inputTxt;
    private TextView outputTxt;
    private ArrayList<User> uArr;
    private String user1Name;
    private final String USER_ONE = "USER1";
    private final String USER_TWO = "USER2";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in_player2);

        udb = new DatabaseManager(getApplicationContext());
        inputTxt = findViewById(R.id.userNameField);
        outputTxt = findViewById(R.id.outPutText);
        uArr = new ArrayList<>();
        uArr = udb.getAllUsers();
        Intent intent = getIntent();
        user1Name = intent.getStringExtra(USER_ONE);

    }

    public void LogInBtn(View view)
    {
        String uName = inputTxt.getText().toString();

        uArr = udb.getAllUsers();
        if(isInDB(uName))
        {
            if(uName.equals(user1Name))
            {
                outputTxt.setText("That's Player 1");
            }
            else
            {
                //This would go into the main activity
                //Puts the two usernames in an intent and is travels throughout the program
                //Once we get to the main activity we can do this and use it throughout instead of using intents
                //public static User finalUser1;
                //public static User finalUser2;
                //We just need to initialize it in the main menu.
                //We would just search the database and the search would return a User if found and yeah.


                Intent myIntent = new Intent(this, SampleMainMeny.class);
                myIntent.putExtra(USER_ONE,user1Name);
                myIntent.putExtra(USER_TWO,uName);
                this.startActivity(myIntent);
            }

        }
        else
        {
            outputTxt.setText("User Not Found");
        }
    }

    public void CreateBtn(View view)
    {
        String uName = inputTxt.getText().toString();
        uArr = udb.getAllUsers();
        if(isInDB(uName))
        {
            outputTxt.setText("Enter A Different Username");
        }
        else
        {
            User x = new User();
            x.setUsername(uName);
            x.setQuesRight(0);
            x.setQuesWrong(0);
            udb.insertUser(x);

//            This would go into the main activity also.

//            Intent myIntent = new Intent(this, MainActivity.class);
////            myIntent.putExtra(USER_ONE,user1Name);
////            myIntent.putExtra(USER_TWO,uName);
////            this.startActivity(myIntent);

            Intent myIntent = new Intent(this, SampleMainMeny.class);
            myIntent.putExtra(USER_ONE,user1Name);
            myIntent.putExtra(USER_TWO,uName);
            this.startActivity(myIntent);
        }
    }

    public boolean isInDB(String x)
    {

        if (x != "") {
            for (int i = 0; (i < uArr.size()); i++) {
                if (x.equals(uArr.get(i).getUsername())) {
                    return true;
                }
            }
        }

        return false;
    }

    public User retrunUser(String x)
    {

        if (x != "") {
            for (int i = 0; (i < uArr.size()); i++) {
                if (x.equals(uArr.get(i).getUsername())) {
                    return uArr.get(i);
                }
            }
        }

        return null;
    }

}


